## Addition Example

### Functions

* get_sum: for two numbers
* get_sum_all: for any list of numbers
